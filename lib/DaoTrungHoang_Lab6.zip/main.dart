import 'package:flutter/material.dart';

void main() {
  runApp(const ResponsiveMovieApp());
}

class Movie {
  final String title;
  final int year;
  final List<String> genres;
  final String posterUrl;
  final double rating;

  Movie({
    required this.title,
    required this.year,
    required this.genres,
    required this.posterUrl,
    required this.rating,
  });
}

class ResponsiveMovieApp extends StatelessWidget {
  const ResponsiveMovieApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Responsive Movie Browser',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.deepPurple,
        useMaterial3: true,
      ),
      home: const GenreScreen(),
    );
  }
}

class GenreScreen extends StatefulWidget {
  const GenreScreen({super.key});

  @override
  State<GenreScreen> createState() => _GenreScreenState();
}

class _GenreScreenState extends State<GenreScreen> {
  final List<Movie> _allMovies = [
    Movie(
      title: 'Inception',
      year: 2010,
      genres: ['Sci-Fi', 'Action'],
      posterUrl: 'https://via.placeholder.com/150/0000FF/808080?text=Inception',
      rating: 8.8,
    ),
    Movie(
      title: 'The Dark Knight',
      year: 2008,
      genres: ['Action', 'Drama'],
      posterUrl: 'https://via.placeholder.com/150/000000/FFFFFF?text=The+Dark+Knight',
      rating: 9.0,
    ),
    Movie(
      title: 'Interstellar',
      year: 2014,
      genres: ['Sci-Fi', 'Drama'],
      posterUrl: 'https://via.placeholder.com/150/FF0000/FFFFFF?text=Interstellar',
      rating: 8.6,
    ),
    Movie(
      title: 'Pulp Fiction',
      year: 1994,
      genres: ['Crime', 'Drama'],
      posterUrl: 'https://via.placeholder.com/150/FFFF00/000000?text=Pulp+Fiction',
      rating: 8.9,
    ),
    Movie(
      title: 'The Matrix',
      year: 1999,
      genres: ['Sci-Fi', 'Action'],
      posterUrl: 'https://via.placeholder.com/150/00FF00/000000?text=The+Matrix',
      rating: 8.7,
    ),
    Movie(
      title: 'The Godfather',
      year: 1972,
      genres: ['Crime', 'Drama'],
      posterUrl: 'https://via.placeholder.com/150/8B4513/FFFFFF?text=The+Godfather',
      rating: 9.2,
    ),
  ];

  final List<String> _availableGenres = [
    'Action',
    'Drama',
    'Sci-Fi',
    'Crime',
    'Comedy',
    'Horror'
  ];

  String _searchQuery = '';
  final Set<String> _selectedGenres = {};
  String _selectedSort = 'A-Z';

  List<Movie> get _filteredMovies {
    List<Movie> filtered = _allMovies.where((movie) {
      final matchesSearch =
          movie.title.toLowerCase().contains(_searchQuery.toLowerCase());
      final matchesGenre = _selectedGenres.isEmpty ||
          movie.genres.any((genre) => _selectedGenres.contains(genre));
      return matchesSearch && matchesGenre;
    }).toList();

    switch (_selectedSort) {
      case 'A-Z':
        filtered.sort((a, b) => a.title.compareTo(b.title));
        break;
      case 'Z-A':
        filtered.sort((a, b) => b.title.compareTo(a.title));
        break;
      case 'Year':
        filtered.sort((a, b) => b.year.compareTo(a.year));
        break;
      case 'Rating':
        filtered.sort((a, b) => b.rating.compareTo(a.rating));
        break;
    }
    return filtered;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Find a Movie',
                style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 16),
              _buildSearchBar(),
              const SizedBox(height: 16),
              _buildGenreChips(),
              const SizedBox(height: 16),
              _buildSortBar(),
              const SizedBox(height: 16),
              Expanded(child: _buildResponsiveMovieList()),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSearchBar() {
    return TextField(
      decoration: InputDecoration(
        hintText: 'Search movies...',
        prefixIcon: const Icon(Icons.search),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(30),
        ),
        filled: true,
        fillColor: Colors.grey[200],
      ),
      onChanged: (value) {
        setState(() {
          _searchQuery = value;
        });
      },
    );
  }

  Widget _buildGenreChips() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Text('Genres', style: TextStyle(fontWeight: FontWeight.bold)),
            if (_selectedGenres.isNotEmpty)
              Container(
                margin: const EdgeInsets.only(left: 8),
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: Colors.deepPurple,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  '${_selectedGenres.length}',
                  style: const TextStyle(color: Colors.white, fontSize: 12),
                ),
              ),
            const Spacer(),
            if (_selectedGenres.isNotEmpty)
              TextButton(
                onPressed: () => setState(() => _selectedGenres.clear()),
                child: const Text('Clear filters'),
              ),
          ],
        ),
        Wrap(
          spacing: 8.0,
          runSpacing: 4.0,
          children: _availableGenres.map((genre) {
            final isSelected = _selectedGenres.contains(genre);
            return FilterChip(
              label: Text(genre),
              selected: isSelected,
              onSelected: (selected) {
                setState(() {
                  if (selected) {
                    _selectedGenres.add(genre);
                  } else {
                    _selectedGenres.remove(genre);
                  }
                });
              },
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildSortBar() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        const Text('Sort by:', style: TextStyle(fontWeight: FontWeight.bold)),
        DropdownButton<String>(
          value: _selectedSort,
          items: ['A-Z', 'Z-A', 'Year', 'Rating'].map((String value) {
            return DropdownMenuItem<String>(
              value: value,
              child: Text(value),
            );
          }).toList(),
          onChanged: (newValue) {
            if (newValue != null) {
              setState(() {
                _selectedSort = newValue;
              });
            }
          },
        ),
      ],
    );
  }

  Widget _buildResponsiveMovieList() {
    final movies = _filteredMovies;
    if (movies.isEmpty) {
      return const Center(child: Text('No movies found.'));
    }

    return LayoutBuilder(
      builder: (context, constraints) {
        if (constraints.maxWidth < 800) {
          return ListView.builder(
            itemCount: movies.length,
            itemBuilder: (context, index) => _buildMovieCard(movies[index], constraints.maxWidth),
          );
        } else {
          return GridView.builder(
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              childAspectRatio: 2.5,
              crossAxisSpacing: 16,
              mainAxisSpacing: 16,
            ),
            itemCount: movies.length,
            itemBuilder: (context, index) => _buildMovieCard(movies[index], constraints.maxWidth / 2),
          );
        }
      },
    );
  }

  Widget _buildMovieCard(Movie movie, double itemWidth) {
    return Card(
      elevation: 2,
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.network(
                movie.posterUrl,
                width: itemWidth > 400 ? 100 : 80,
                height: itemWidth > 400 ? 150 : 120,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) =>
                    const Icon(Icons.movie, size: 50),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    movie.title,
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  Text('Year: ${movie.year}'),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      const Icon(Icons.star, color: Colors.amber, size: 16),
                      const SizedBox(width: 4),
                      Text(movie.rating.toString()),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Wrap(
                    spacing: 4,
                    children: movie.genres
                        .map((g) => Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(
                                color: Colors.grey[200],
                                borderRadius: BorderRadius.circular(4),
                              ),
                              child: Text(g, style: const TextStyle(fontSize: 10)),
                            ))
                        .toList(),
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
